//
//  SubmissionURLComposeController.h
//  newsyc
//
//  Created by Grant Paul on 3/31/11.
//  Copyright 2011 Xuzz Productions, LLC. All rights reserved.
//

#import "ComposeController.h"
#import "HNKit.h"

@interface SubmissionURLComposeController : ComposeController {
    UITextField *titleField;
}

@end
