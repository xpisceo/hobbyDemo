//
//  MoreController.h
//  newsyc
//
//  Created by Grant Paul on 3/9/11.
//  Copyright 2011 Xuzz Productions, LLC. All rights reserved.
//

@interface MoreController : UIViewController <UITableViewDelegate, UITableViewDataSource> {
    UITableView *tableView;
}

@end
