//
//  NSArray+Strings.h
//  newsyc
//
//  Created by Alex Galonsky on 4/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSArray (Strings)

- (BOOL)containsString:(NSString *)string;

@end
