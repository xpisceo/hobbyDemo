//
//  NSString+Tags.h
//  newsyc
//
//  Created by Grant Paul on 3/13/11.
//  Copyright 2011 Xuzz Productions, LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Tags)

- (NSString *)stringByRemovingHTMLTags;

@end
