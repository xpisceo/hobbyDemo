//
//  NSString+URLEncoding.h
//  newsyc
//
//  Created by Grant Paul on 3/10/11.
//  Copyright 2011 Xuzz Productions, LLC. All rights reserved.
//

@interface NSString (URLEncoding)

- (NSString *)stringByURLEncodingString;

@end
