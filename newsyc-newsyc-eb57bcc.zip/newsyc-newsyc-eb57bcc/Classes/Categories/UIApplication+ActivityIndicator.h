//
//  UIApplication+ActivityIndicator.h
//  newsyc
//
//  Created by Grant Paul on 5/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

@interface UIApplication (ActivityIndicator)

- (void)retainNetworkActivityIndicator;
- (void)releaseNetworkActivityIndicator;

@end
